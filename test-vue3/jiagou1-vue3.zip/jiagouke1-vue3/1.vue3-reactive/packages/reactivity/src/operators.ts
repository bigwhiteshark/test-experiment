export const enum TrackOpTypes {
    GET
}

export const enum TriggerOrTypes {
    ADD,
    SET
}