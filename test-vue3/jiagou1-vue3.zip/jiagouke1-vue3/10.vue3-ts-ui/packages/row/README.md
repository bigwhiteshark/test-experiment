# `row`

> TODO: description

## Usage

```
const row = require('row');

// TODO: DEMONSTRATE API
```
