# `transfer`

> TODO: description

## Usage

```
const transfer = require('transfer');

// TODO: DEMONSTRATE API
```
