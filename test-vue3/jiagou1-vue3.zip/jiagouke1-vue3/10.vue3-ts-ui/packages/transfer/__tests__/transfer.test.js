'use strict';

const transfer = require('..');

describe('transfer', () => {
    it('needs tests');
});
