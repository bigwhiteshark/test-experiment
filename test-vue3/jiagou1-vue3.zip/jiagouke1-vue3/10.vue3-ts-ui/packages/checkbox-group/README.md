# `checkbox-group`

> TODO: description

## Usage

```
const checkboxGroup = require('checkbox-group');

// TODO: DEMONSTRATE API
```
