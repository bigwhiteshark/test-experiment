'use strict';

const checkboxGroup = require('..');

describe('checkbox-group', () => {
    it('needs tests');
});
