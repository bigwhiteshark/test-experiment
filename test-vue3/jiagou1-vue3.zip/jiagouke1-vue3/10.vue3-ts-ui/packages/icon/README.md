# `icon`

> TODO: description

## Usage

```
const icon = require('icon');

// TODO: DEMONSTRATE API
```
