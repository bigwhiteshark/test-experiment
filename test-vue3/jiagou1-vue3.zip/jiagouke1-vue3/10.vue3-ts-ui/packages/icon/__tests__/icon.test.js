'use strict';

const icon = require('..');

describe('icon', () => {
    it('needs tests');
});
