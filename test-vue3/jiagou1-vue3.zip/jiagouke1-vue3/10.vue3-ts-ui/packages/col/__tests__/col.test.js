'use strict';

const col = require('..');

describe('col', () => {
    it('needs tests');
});
