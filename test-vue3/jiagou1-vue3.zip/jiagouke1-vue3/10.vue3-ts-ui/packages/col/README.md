# `col`

> TODO: description

## Usage

```
const col = require('col');

// TODO: DEMONSTRATE API
```
