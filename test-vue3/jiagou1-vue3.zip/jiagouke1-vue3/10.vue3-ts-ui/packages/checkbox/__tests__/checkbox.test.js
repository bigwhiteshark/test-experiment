'use strict';

const checkbox = require('..');

describe('checkbox', () => {
    it('needs tests');
});
