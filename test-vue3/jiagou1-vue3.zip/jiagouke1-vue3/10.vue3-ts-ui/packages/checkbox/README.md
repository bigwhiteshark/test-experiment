# `checkbox`

> TODO: description

## Usage

```
const checkbox = require('checkbox');

// TODO: DEMONSTRATE API
```
