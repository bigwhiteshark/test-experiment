'use strict';

const button = require('..');

describe('button', () => {
    it('needs tests');
});
