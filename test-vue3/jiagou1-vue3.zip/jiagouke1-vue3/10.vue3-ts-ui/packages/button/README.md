# `button`

> TODO: description

## Usage

```
const button = require('button');

// TODO: DEMONSTRATE API
```
