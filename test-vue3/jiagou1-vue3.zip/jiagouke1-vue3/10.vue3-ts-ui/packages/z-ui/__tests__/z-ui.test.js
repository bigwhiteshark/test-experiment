'use strict';

const zUi = require('..');

describe('z-ui', () => {
    it('needs tests');
});
