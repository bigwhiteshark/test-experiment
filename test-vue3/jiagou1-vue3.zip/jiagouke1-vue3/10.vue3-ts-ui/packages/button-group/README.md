# `button-group`

> TODO: description

## Usage

```
const buttonGroup = require('button-group');

// TODO: DEMONSTRATE API
```
